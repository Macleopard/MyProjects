void name(char *name);
void name1();
void error();